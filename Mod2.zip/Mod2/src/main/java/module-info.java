module com.example.mod2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.knowm.xchart;


    opens com.example.mod2 to javafx.fxml;
    exports com.example.mod2;
}